# Ligne 80 Naolib — Haluchère-Batignolles ↔ Fac de Droit

**Map Proton Bus Simulator mobile / Android — build généré, pas encore testé dans le jeu.**

## Tracé modélisé

Le parcours est reconstruit sur le corridor réel de la ligne 80 depuis Haluchère-Batignolles vers le campus du Tertre : Ranzay, Porte de La Chapelle, Recteur Schmitt, École Centrale–Audencia, Fac de Droit. Vérification du tracé : les relations OSM des deux sens incluent les chaussées du N844 (intérieure et extérieure), les bretelles et le pont de la Beaujoire ; le périphérique est donc bien emprunté sur ce tronçon, pas seulement placé à proximité en décor.

Les six arrêts repères configurés en jeu (Haluchère-Batignolles, Ranzay, Porte de La Chapelle, Recteur Schmitt, École Centrale–Audencia, Fac de Droit) correspondent aux points horaires de la fiche Naolib valable du 31 août 2026 au 5 mai 2027. La fiche mentionne aussi des arrêts intermédiaires — notamment Terray, Grande Censive et Fac de Lettres — qui ne sont pas configurés comme arrêts dans cette version. La géométrie du tronçon, elle, suit le corridor routier réel. Les relations OSM servent à reconstruire cette voie ; la séquence des six arrêts affichés suit la fiche horaire, non les anciennes listes de stops des relations OSM.

## Contenu

- deux entrées jouables, dans les deux sens ;
- arrêts, plateformes, abribus vitrés, quais et marqueurs passagers ;
- bâtiments issus des empreintes OSM, façades universitaires, trottoirs, cheminements, rails/tram contextuels et arbres sur plans alpha croisés ;
- mobilier routier autour de la Porte de La Chapelle / N844 ;
- plan d'aperçu à l'échelle, détails Haluchère, périphérique et campus ;
- textures PNG autonomes.

## Import

Sur Android récent, privilégier l’installateur de mods intégré à Proton Bus : ouvrir la sélection de maps, toucher `+`, puis choisir directement `Ligne80Nantes.zip` (ne pas le décompresser avant). Selon Android 11+, il peut falloir placer le ZIP dans un dossier accessible depuis `Téléchargements`. Pour une installation manuelle/ancienne version, extraire **le contenu complet** en conservant `Ligne80Nantes.map.txt` à côté du dossier `Ligne80Nantes`. Redémarrer le jeu puis sélectionner l’une des deux entrées. L'installation et la conduite n'ont pas encore été vérifiées sur un appareil Android.

## Sources et licences

- Naolib, horaires officiels ligne 80 (31/08/2026–05/05/2027) : https://naolib.fr/medias/fichier/depliant-l-80-web_1784100508331?INLINE=FALSE
- Nantes Université, plans des campus : https://www.univ-nantes.fr/plan
- UFR Sciences et Techniques, accès au campus Lombarderie (périphérique Est / Porte de La Chapelle) : https://sciences-techniques.univ-nantes.fr/actualites-agenda/acces-au-campus-lombarderie
- OpenStreetMap contributors, relations 1710519 et 1710524 et éléments du corridor (données ODbL) : https://www.openstreetmap.org/relation/1710519 ; https://www.openstreetmap.org/relation/1710524
- Corroboration historique du passage par le périphérique Est : fermeture/inondation de la N844 et interruption de la ligne 80 entre Haluchère et Fac de Droit (Actu, 04/01/2024) : https://actu.fr/pays-de-la-loire/nantes_44109/peripherique-de-nantes-une-partie-reste-inondee-et-fermee-ce-jeudi_60518624.html
- Références visuelles du pôle d'Haluchère et du campus consultées en ligne ; aucune photographie externe n'est intégrée comme texture. Les textures de la map sont procédurales.

## Contrôle du build

- Longueur géométrique OSM : environ 5.61 km aller, 5.47 km retour.
- Voies contextualisées : 2008; bâtiments : 2096; arbres en billboards : 391.
- Classes de voies incluant le corridor N844 : trunk, trunk_link.
- Contrôle du fichier 3DS et de la structure effectué par le générateur ; aucun test en jeu n'est revendiqué.
