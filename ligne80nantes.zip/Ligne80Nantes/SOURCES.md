# Sources de référence

- Horaires / arrêts ligne 80 Naolib, fiche valable du 31 août 2026 au 5 mai 2027 : https://naolib.fr/medias/fichier/depliant-l-80-web_1784100508331?INLINE=FALSE
- Plans Nantes Université : https://www.univ-nantes.fr/plan
- Accès officiel campus Lombarderie depuis le périphérique Est et sortie Porte de La Chapelle : https://sciences-techniques.univ-nantes.fr/actualites-agenda/acces-au-campus-lombarderie
- Tracé géométrique : OpenStreetMap, relations 1710519 (sens Bellevue vers Fac de Droit) et 1710524 (sens inverse), corridor OSM local filtré ; données sous ODbL.
- Corroboration historique du passage par le périphérique Est : fermeture/inondation de la N844 et interruption de la ligne 80 entre Haluchère et Fac de Droit (Actu, 04/01/2024) : https://actu.fr/pays-de-la-loire/nantes_44109/peripherique-de-nantes-une-partie-reste-inondee-et-fermee-ce-jeudi_60518624.html
- Repères visuels consultés : pôle d'échanges Haluchère-Batignolles (structure métallique et vitrages) ; bâtiments du campus du Tertre / Lombarderie (béton, verre, espaces arborés). Les photos servent uniquement de référence, aucune photo n'est embarquée.
